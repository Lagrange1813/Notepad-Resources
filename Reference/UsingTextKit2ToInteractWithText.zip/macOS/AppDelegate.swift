/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The application-specific delegate class.
*/

import Cocoa

@main
class AppDelegate: NSObject, NSApplicationDelegate {

    func applicationDidFinishLaunching(_ notification: Notification) {
        //..
    }
    
    func applicationWillTerminate(_ notification: Notification) {
        //..
    }
}
