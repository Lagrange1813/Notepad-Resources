/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The application's UIWindowScene subclass for managing its window.
*/

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        //..
    }

}
