# Using TextKit 2 to Interact with Text

Interact with text by managing text selection and inserting custom text elements.

## Overview

- Note: This sample code project is associated with WWDC21 session [10061: Meet TextKit 2](https://developer.apple.com/wwdc21/10061/)
