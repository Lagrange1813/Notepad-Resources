import {codeRender} from "./editor/markdown/codeRender";
import {highlightRender} from "./editor/markdown/highlightRender";
import {outlineRender} from "./editor/markdown/outlineRender";
import {md2html, previewRender} from "./editor/markdown/previewRender";
import {setCodeTheme} from "./editor/ui/setCodeTheme";
import {setContentTheme} from "./editor/ui/setContentTheme";

class LGEditor {
    /** 为 element 中的代码块添加复制按钮 */
    public static codeRender = codeRender;
    /** 为 element 中的代码块进行高亮渲染 */
    public static highlightRender = highlightRender;
    /** 大纲渲染 */
    public static outlineRender = outlineRender;
    /** Markdown 文本转换为 HTML，该方法需使用[异步编程](https://ld246.com/article/1546828434083?r=Vaness) */
    public static md2html = md2html;
    /** 页面 Markdown 文章渲染 */
    public static preview = previewRender;
    /** 设置代码主题 */
    public static setCodeTheme = setCodeTheme;
    /** 设置内容主题 */
    public static setContentTheme = setContentTheme;
}

export default LGEditor;
