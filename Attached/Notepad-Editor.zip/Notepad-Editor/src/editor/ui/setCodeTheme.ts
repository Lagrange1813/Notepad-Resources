import {Constants} from "../constants";
import {addStyle} from "../util/addStyle";

export const setCodeTheme = (codeTheme: string, cdn = Constants.CDN) => {
    if (!Constants.CODE_THEME.includes(codeTheme)) {
        codeTheme = "github";
    }
    const lgEditorHljsStyle = document.getElementById("lgEditorHljsStyle") as HTMLLinkElement;
    const href = `${cdn}/dist/js/highlight.js/styles/${codeTheme}.css`;
    if (!lgEditorHljsStyle) {
        addStyle(href, "lgEditorHljsStyle");
    } else if (lgEditorHljsStyle.href !== href) {
        lgEditorHljsStyle.remove();
        addStyle(href, "lgEditorHljsStyle");
    }
};
