import {addStyle} from "../util/addStyle";

export const setContentTheme = (contentTheme: string, path: string) => {
    if (!contentTheme || !path) {
        return;
    }
    const lgEditorContentTheme = document.getElementById("lgEditorContentTheme") as HTMLLinkElement;
    const cssPath = `${path}/${contentTheme}.css`;
    if (!lgEditorContentTheme) {
        addStyle(cssPath, "lgEditorContentTheme");
    } else if (lgEditorContentTheme.getAttribute("href") !== cssPath) {
        lgEditorContentTheme.remove();
        addStyle(cssPath, "lgEditorContentTheme");
    }
};
