class IR {
    constructor() {
        const divElement = document.createElement("div");
        divElement.className = "editor-ir";

        divElement.innerHTML = `<pre class="vditor-reset" placeholder="test" contenteditable="true" spellcheck="false"></pre>`;
    }
}