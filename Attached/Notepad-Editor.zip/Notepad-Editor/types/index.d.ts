interface LGObject {
    [key: string]: string;
}

interface LGLuteNode {
    TokensStr: () => string;
    __internal_object__: {
        Parent: {
            Type: number,
        },
        HeadingLevel: string,
    };
}

type LGLuteRenderCallback = (node: LGLuteNode, entering: boolean) => [string, number];

interface LGLuteRender {
    renderDocument?: LGLuteRenderCallback;
    renderParagraph?: LGLuteRenderCallback;
    renderText?: LGLuteRenderCallback;
    renderCodeBlock?: LGLuteRenderCallback;
    renderCodeBlockOpenMarker?: LGLuteRenderCallback;
    renderCodeBlockInfoMarker?: LGLuteRenderCallback;
    renderCodeBlockCode?: LGLuteRenderCallback;
    renderCodeBlockCloseMarker?: LGLuteRenderCallback;
    renderMathBlock?: LGLuteRenderCallback;
    renderMathBlockOpenMarker?: LGLuteRenderCallback;
    renderMathBlockContent?: LGLuteRenderCallback;
    renderMathBlockCloseMarker?: LGLuteRenderCallback;
    renderBlockquote?: LGLuteRenderCallback;
    renderBlockquoteMarker?: LGLuteRenderCallback;
    renderHeading?: LGLuteRenderCallback;
    renderHeadingC8hMarker?: LGLuteRenderCallback;
    renderList?: LGLuteRenderCallback;
    renderListItem?: LGLuteRenderCallback;
    renderTaskListItemMarker?: LGLuteRenderCallback;
    renderThematicBreak?: LGLuteRenderCallback;
    renderHTML?: LGLuteRenderCallback;
    renderTable?: LGLuteRenderCallback;
    renderTableHead?: LGLuteRenderCallback;
    renderTableRow?: LGLuteRenderCallback;
    renderTableCell?: LGLuteRenderCallback;
    renderFootnotesDef?: LGLuteRenderCallback;
    renderCodeSpan?: LGLuteRenderCallback;
    renderCodeSpanOpenMarker?: LGLuteRenderCallback;
    renderCodeSpanContent?: LGLuteRenderCallback;
    renderCodeSpanCloseMarker?: LGLuteRenderCallback;
    renderInlineMath?: LGLuteRenderCallback;
    renderInlineMathOpenMarker?: LGLuteRenderCallback;
    renderInlineMathContent?: LGLuteRenderCallback;
    renderInlineMathCloseMarker?: LGLuteRenderCallback;
    renderEmphasis?: LGLuteRenderCallback;
    renderEmAsteriskOpenMarker?: LGLuteRenderCallback;
    renderEmAsteriskCloseMarker?: LGLuteRenderCallback;
    renderEmUnderscoreOpenMarker?: LGLuteRenderCallback;
    renderEmUnderscoreCloseMarker?: LGLuteRenderCallback;
    renderStrong?: LGLuteRenderCallback;
    renderStrongA6kOpenMarker?: LGLuteRenderCallback;
    renderStrongA6kCloseMarker?: LGLuteRenderCallback;
    renderStrongU8eOpenMarker?: LGLuteRenderCallback;
    renderStrongU8eCloseMarker?: LGLuteRenderCallback;
    renderStrikethrough?: LGLuteRenderCallback;
    renderStrikethrough1OpenMarker?: LGLuteRenderCallback;
    renderStrikethrough1CloseMarker?: LGLuteRenderCallback;
    renderStrikethrough2OpenMarker?: LGLuteRenderCallback;
    renderStrikethrough2CloseMarker?: LGLuteRenderCallback;
    renderHardBreak?: LGLuteRenderCallback;
    renderSoftBreak?: LGLuteRenderCallback;
    renderInlineHTML?: LGLuteRenderCallback;
    renderLink?: LGLuteRenderCallback;
    renderOpenBracket?: LGLuteRenderCallback;
    renderCloseBracket?: LGLuteRenderCallback;
    renderOpenParen?: LGLuteRenderCallback;
    renderCloseParen?: LGLuteRenderCallback;
    renderLinkText?: LGLuteRenderCallback;
    renderLinkSpace?: LGLuteRenderCallback;
    renderLinkDest?: LGLuteRenderCallback;
    renderLinkTitle?: LGLuteRenderCallback;
    renderImage?: LGLuteRenderCallback;
    renderBang?: LGLuteRenderCallback;
    renderEmoji?: LGLuteRenderCallback;
    renderEmojiUnicode?: LGLuteRenderCallback;
    renderEmojiImg?: LGLuteRenderCallback;
    renderEmojiAlias?: LGLuteRenderCallback;
    renderToC?: LGLuteRenderCallback;
    renderFootnotesRef?: LGLuteRenderCallback;
    renderBackslash?: LGLuteRenderCallback;
    renderBackslashContent?: LGLuteRenderCallback;
}

declare class Lute {
    public static WalkStop: number;
    public static WalkSkipChildren: number;
    public static WalkContinue: number;
    public static Version: string;
    public static Caret: string;

    public static New(): Lute;

    public static GetHeadingID(node: LGLuteNode): string;

    public static NewNodeID(): string;

    public static Sanitize(html: string): string;

    private constructor();

    public SetJSRenderers(options?: {
        renderers: {
            HTML2VditorDOM?: LGLuteRender,
            HTML2VditorIRDOM?: LGLuteRender,
            HTML2Md?: LGLuteRender,
            Md2HTML?: LGLuteRender,
            Md2VditorDOM?: LGLuteRender,
            Md2VditorIRDOM?: LGLuteRender,
            Md2VditorSVDOM?: LGLuteRender,
        },
    }): void;

    public SetChineseParagraphBeginningSpace(enable: boolean): void;

    public SetHeadingID(enable: boolean): void;

    public SetRenderListStyle(enable: boolean): void;

    public SetLinkBase(url: string): void;

    public SetVditorIR(enable: boolean): void;

    public SetVditorSV(enable: boolean): void;

    public SetVditorWYSIWYG(enable: boolean): void;

    public SetLinkPrefix(url: string): void;

    public SetMark(enable: boolean): void;

    public SetSanitize(enable: boolean): void;

    public SetHeadingAnchor(enable: boolean): void;

    public SetImageLazyLoading(imagePath: string): void;

    public SetInlineMathAllowDigitAfterOpenMarker(enable: boolean): void;

    public SetToC(enable: boolean): void;

    public SetFootnotes(enable: boolean): void;

    public SetAutoSpace(enable: boolean): void;

    public SetFixTermTypo(enable: boolean): void;

    public SetEmojiSite(emojiSite: string): void;

    public SetVditorCodeBlockPreview(enable: boolean): void;

    public SetVditorMathBlockPreview(enable: boolean): void;

    public PutEmojis(emojis: LGObject): void;

    public GetEmojis(): LGObject;

    // debugger md
    public RenderEChartsJSON(text: string): string;

    // md 转换为 html
    public Md2HTML(markdown: string): string;

    // 粘贴时将 html 转换为 md
    public HTML2Md(html: string): string;

    // wysiwyg 转换为 html
    public VditorDOM2HTML(vhtml: string): string;

    // wysiwyg 输入渲染
    public SpinVditorDOM(html: string): string;

    // 粘贴时将 html 转换为 wysiwyg
    public HTML2VditorDOM(html: string): string;

    // 将 wysiwyg 转换为 md
    public VditorDOM2Md(html: string): string;

    // 将 md 转换为 wysiwyg
    public Md2VditorDOM(markdown: string): string;

    // ir 输入渲染
    public SpinVditorIRDOM(markdown: string): string;

    // ir 获取 md
    public VditorIRDOM2Md(html: string): string;

    // md 转换为 ir
    public Md2VditorIRDOM(text: string): string;

    // 获取 HTML
    public VditorIRDOM2HTML(html: string): string;

    // 粘贴时将 html 转换为 sv
    public HTML2VditorIRDOM(html: string): string;

    // sv 输入渲染
    public SpinVditorSVDOM(text: string): string;

    // 粘贴是 md 转换为 sv
    public Md2VditorSVDOM(text: string): string;

    // 将markdown转化为JSON结构输出 https://github.com/88250/lute/issues/120
    public RenderJSON(markdown: string): string;
}

interface LGEditor {
    element: HTMLElement;
    originalInnerHTML: string;
    lute: Lute;
    currentMode: "sv" | "ir";
    outline: {
        element: HTMLElement,
        render(vditor: LGEditor): string,
        toggle(vditor: LGEditor, show?: boolean): void,
    };
    preview?: {
        element: HTMLElement
        render(vditor: LGEditor, value?: string): void,
    };
    resize?: {
        element: HTMLElement,
    };
    tip: {
        element: HTMLElement
        show(text: string, time?: number): void
        hide(): void,
    };
    ir?: {
        range: Range,
        element: HTMLPreElement,
        composingLock: boolean,
        preventInput: boolean,
        processTimeoutId: number,
        hlToolbarTimeoutId: number,
    };
    sv?: {
        range: Range,
        element: HTMLPreElement,
        processTimeoutId: number,
        hlToolbarTimeoutId: number,
        composingLock: boolean,
        preventInput: boolean,
    };
}

/** @link https://ld246.com/article/1549638745630#options-preview-hljs */
interface LGHljs {
    /** 是否启用行号。默认值: false */
    lineNumber?: boolean;
    /** 代码风格，可选值参见 [Chroma](https://xyproto.github.io/splash/docs/longer/all.html)。 默认值: 'github' */
    style?: string;
    /** 是否启用代码高亮。默认值: true */
    enable?: boolean;
}

interface LGPreviewTheme {
    current: string;
    list?: LGObject;
    path?: string;
}

/** @link https://ld246.com/article/1549638745630#options-preview-markdown */
interface LGMarkdownConfig {
    /** 自动空格。默认值: false */
    autoSpace?: boolean;
    /** 段落开头是否空两格。默认值: false */
    paragraphBeginningSpace?: boolean;
    /** 自动矫正术语。默认值: false */
    fixTermTypo?: boolean;
    /** 插入目录。默认值: false */
    toc?: boolean;
    /** 脚注。默认值: true */
    footnotes?: boolean;
    /** wysiwyg & ir 模式代码块是否渲染。默认值: true */
    codeBlockPreview?: boolean;
    /** wysiwyg & ir 模式数学公式块是否渲染。默认值: true */
    mathBlockPreview?: boolean;
    /** 是否启用过滤 XSS。默认值: true */
    sanitize?: boolean;
    /** 链接相对路径前缀。默认值：'' */
    linkBase?: string;
    /** 链接强制前缀。默认值：'' */
    linkPrefix?: string;
    /** 为列表添加标记，以便[自定义列表样式](https://github.com/Vanessa219/vditor/issues/390) 默认值：false */
    listStyle?: boolean;
    /** 支持 mark 标记 */
    mark?: boolean;
}

/** @link https://ld246.com/article/1549638745630#options-preview */
interface IPreview {
    /** 预览 debounce 毫秒间隔。默认值: 1000 */
    delay?: number;
    /** 预览区域最大宽度。默认值: 768 */
    maxWidth?: number;
    /** 显示模式。默认值: 'both' */
    mode?: "both" | "editor";
    /** md 解析请求 */
    url?: string;
    /** @link https://ld246.com/article/1549638745630#options-preview-hljs */
    hljs?: LGHljs;
    /** @link https://ld246.com/article/1549638745630#options-preview-math */
    markdown?: LGMarkdownConfig;
    /** @link https://ld246.com/article/1549638745630#options-preview-theme */
    theme?: LGPreviewTheme;
    /** @link https://ld246.com/article/1549638745630#options-preview-actions  */
    actions?: Array<LGPreviewAction | LGPreviewActionCustom>;

    /** 预览回调 */
    parse?(element: HTMLElement): void;

    /** 渲染之前回调 */
    transform?(html: string): string;
}

type LGPreviewAction = "desktop" | "tablet" | "mobile" | "mp-wechat" | "zhihu";

interface LGPreviewActionCustom {
    /** 键名 */
    key: string;
    /** 按钮文本 */
    text: string;
    /** 按钮 className 值 */
    className?: string;
    /** 按钮提示信息 */
    tooltip?: string;
    /** 点击回调 */
    click: (key: string) => void;
}

interface LGLuteOptions extends LGMarkdownConfig {
    emojis: LGObject;
    emojiSite: string;
    headingAnchor: boolean;
    inlineMathDigit: boolean;
    lazyLoadImage?: string;
}

interface LGPreviewOptions {
    mode: "dark" | "light";
    customEmoji?: LGObject;
    lazyLoadImage?: string;
    emojiPath?: string;
    hljs?: LGHljs;
    speech?: {
        enable?: boolean,
    };
    anchor?: number; // 0: no render, 1: render left, 2: render right
    cdn?: string;
    markdown?: LGMarkdownConfig;
    renderers?: LGLuteRender;
    theme?: LGPreviewTheme;
    icon?: "ant" | "material" | undefined;

    transform?(html: string): string;

    after?(): void;
}