//
//  main.m
//  ZSSRichTextEditor
//
//  Created by Nicholas Hubbard on 11/28/13.
//  Copyright (c) 2013 Zed Said Studio. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ZSSAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ZSSAppDelegate class]));
    }
}
