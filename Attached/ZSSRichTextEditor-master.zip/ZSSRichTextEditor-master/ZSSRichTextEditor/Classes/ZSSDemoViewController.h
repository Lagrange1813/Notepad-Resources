//
//  ZSSDemoViewController.h
//  ZSSRichTextEditor
//
//  Created by Nicholas Hubbard on 11/29/13.
//  Copyright (c) 2013 Zed Said Studio. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZSSRichTextEditor.h"

@interface ZSSDemoViewController : ZSSRichTextEditor

@end
