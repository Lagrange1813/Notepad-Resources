# Visiting Markup

## Topics

### Vistor

- ``MarkupVisitor``

### Walker

``MarkupWalker`` is a default implementation for ``MarkupVisitor``.

- ``MarkupWalker``

### Rewriter

- ``MarkupRewriter``
