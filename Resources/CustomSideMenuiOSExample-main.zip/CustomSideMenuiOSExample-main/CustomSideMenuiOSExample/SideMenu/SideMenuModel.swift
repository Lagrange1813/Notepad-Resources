//
//  MenuModel.swift
//  CustomSideMenuiOSExample
//
//  Created by John Codeos on 2/20/21.
//

import UIKit

struct SideMenuModel {
    var icon: UIImage
    var title: String
}
