//
//  BooksViewController.swift
//  CustomSideMenuiOSExample
//
//  Created by John Codeos on 2/9/21.
//

import UIKit

class BooksViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
