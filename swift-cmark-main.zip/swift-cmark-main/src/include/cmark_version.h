#ifndef CMARK_VERSION_H
#define CMARK_VERSION_H

#define CMARK_VERSION ((0 << 16) | (29 << 8) | 0)
#define CMARK_VERSION_STRING "0.29.0"

#endif
